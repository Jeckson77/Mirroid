# StrikeLab A55 Live — Visual Tracking Alpha

An Android MediaProjection prototype for explicit, permission-based live screen capture with a manual tap-to-select target and non-interactive on-screen tracking reticle.

No simulated input, accessibility service, automatic enemy detection, firing, game memory modifications, or anticheat bypass. It is intended for training and permitted testing.

## Build

JDK 17, Gradle 8.9, Android SDK 35. Run `gradle assembleDebug` or use the `strikelab-live-apk.yml` GitHub Actions workflow.

## Known limitations

Tracking is template matching with manual initialization. It can drift or fail on rapid motion and occlusion. Android MediaProjection requires explicit permission and may be unavailable for protected apps. Do not assume overlay compatibility with particular games.
