package com.strikelab.live;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** Pass-through overlay except while explicitly choosing a target. */
public final class TargetOverlay extends View {
    public interface TargetListener {void target(float nx,float ny);}
    private final Paint p=new Paint(3);
    private final TargetListener onTarget;
    private volatile boolean choosing=false,locked=false;
    private volatile float x,y,quality;
    TargetOverlay(Context ctx,TargetListener callback){super(ctx);onTarget=callback;setBackgroundColor(Color.TRANSPARENT);}
    public void setChoosing(boolean v){choosing=v;postInvalidate();}
    public void result(TemplateTracker.Result r){locked=r.locked;x=r.x;y=r.y;quality=r.quality;postInvalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();
        p.setStyle(Paint.Style.FILL);p.setTextSize(Math.max(20,w*.015f));p.setColor(0xDDF5F9FF);
        c.drawText(choosing?"TAP TARGET HEAD — SELECT MODE":(locked?"TRACKING TARGET":"NO TARGET / TRACKING LOST"),20,Math.max(38,h*.065f),p);
        c.drawText("VISUAL GUIDANCE ONLY",20,Math.max(65,h*.11f),p);
        if(!locked)return;
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(2,w*.0015f));p.setColor(0xFF4CC9F0);
        c.drawCircle(x,y,Math.max(13,w*.012f),p);
        c.drawLine(x-25,y,x-9,y,p);c.drawLine(x+9,y,x+25,y,p);
        c.drawLine(x,y-25,x,y-9,p);c.drawLine(x,y+9,x,y+25,p);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(!choosing)return false;
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            onTarget.target(e.getX()/Math.max(1,getWidth()),e.getY()/Math.max(1,getHeight()));
            return true;
        }
        return true;
    }
}
