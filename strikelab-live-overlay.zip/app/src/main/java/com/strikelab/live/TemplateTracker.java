package com.strikelab.live;

import android.media.Image;
import java.nio.ByteBuffer;

/** Lightweight grayscale template matcher. Manual selection required; no enemy classifier. */
public final class TemplateTracker {
    public static final class Result {
        public final float x,y,quality;
        public final boolean locked;
        Result(float x,float y,float q,boolean locked){this.x=x;this.y=y;quality=q;this.locked=locked;}
    }
    private static final int STEP=4, HALF=6, SEARCH=19;
    private volatile float pendingX=-1,pendingY=-1;
    private int iw,ih;
    private byte[] lastTemplate;
    private float cx,cy;
    private int failures;
    public synchronized void select(float nx,float ny){pendingX=Math.max(0,Math.min(1,nx));pendingY=Math.max(0,Math.min(1,ny));lastTemplate=null;failures=0;}
    public synchronized void clear(){lastTemplate=null;pendingX=-1;pendingY=-1;failures=0;}
    public synchronized Result process(Image frame){
        final Image.Plane plane=frame.getPlanes()[0];
        final ByteBuffer buf=plane.getBuffer();
        final int pxStride=plane.getPixelStride(),rowStride=plane.getRowStride();
        int w=frame.getWidth()/STEP,h=frame.getHeight()/STEP;
        if(w<40||h<40)return new Result(0,0,0,false);
        byte[] gray=new byte[w*h];
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){
            int pos=y*STEP*rowStride+x*STEP*pxStride;
            int r=buf.get(pos)&255,g=buf.get(pos+1)&255,b=buf.get(pos+2)&255;
            gray[y*w+x]=(byte)((77*r+150*g+29*b)>>8);
        }
        if(w!=iw||h!=ih){iw=w;ih=h;lastTemplate=null;}
        if(pendingX>=0){
            cx=Math.max(HALF,Math.min(w-HALF-1,Math.round(pendingX*w)));
            cy=Math.max(HALF,Math.min(h-HALF-1,Math.round(pendingY*h)));
            pendingX=-1;pendingY=-1;lastTemplate=extract(gray,w,h,(int)cx,(int)cy);
            return new Result(cx*STEP,cy*STEP,1,true);
        }
        if(lastTemplate==null)return new Result(0,0,0,false);
        int bestX=(int)cx,bestY=(int)cy,best=Integer.MAX_VALUE;
        for(int y=Math.max(HALF,(int)cy-SEARCH);y<=Math.min(h-HALF-1,(int)cy+SEARCH);y++){
            for(int x=Math.max(HALF,(int)cx-SEARCH);x<=Math.min(w-HALF-1,(int)cx+SEARCH);x++){
                int err=0;
                for(int dy=-HALF;dy<=HALF;dy+=2){
                    for(int dx=-HALF;dx<=HALF;dx+=2){
                        int k=(dy+HALF)*(HALF*2+1)+(dx+HALF);
                        err+=Math.abs((gray[(y+dy)*w+x+dx]&255)-(lastTemplate[k]&255));
                    }
                }
                if(err<best){best=err;bestX=x;bestY=y;}
            }
        }
        float error=(float)best/49f;
        if(error>30){failures++;if(failures>=5)lastTemplate=null;return new Result(cx*STEP,cy*STEP,Math.max(0,1-error/60f),false);}
        failures=0;cx=bestX;cy=bestY;
        return new Result(cx*STEP,cy*STEP,Math.max(0,1-error/60f),true);
    }
    private byte[] extract(byte[] pixels,int w,int h,int x,int y){
        byte[] result=new byte[(HALF*2+1)*(HALF*2+1)];int k=0;
        for(int dy=-HALF;dy<=HALF;dy++)for(int dx=-HALF;dx<=HALF;dx++)result[k++]=pixels[(y+dy)*w+x+dx];
        return result;
    }
}
