package com.strikelab.live;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 120;
    private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(9, 16, 32));
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(35, 48, 35, 35);
        scroll.addView(body);
        heading(body,"STRIKELAB  /  LIVE ALPHA",26,0xFF4CC9F0,true);
        heading(body,"Samsung A55 • Android • v0.2.0",14,0xFFAFBAD5,false);
        heading(body,"Live screen tracking with visual head-target guidance",18,Color.WHITE,true);
        heading(body,"Select a visible practice target manually. This app shows real-time visual guidance only; it does not control game inputs, recognize enemies automatically, or fire weapons.",15,0xFFD0D8E7,false);
        button(body,"1. Allow floating overlay",() -> {
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);
        });
        button(body,"2. Start live screen capture",()-> {
            if(!Settings.canDrawOverlays(this)){status.setText("Enable display-over-other-apps first.");return;}
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(),CAPTURE_REQUEST);
        });
        button(body,"Select target (then tap on screen)",()-> command(CaptureService.ACTION_SELECT));
        button(body,"Stop capture and clear target",()->command(CaptureService.ACTION_STOP));
        status=new TextView(this);status.setTextColor(0xFF92D9F3);status.setTextSize(15);status.setPadding(0,26,0,14);status.setText("Start capture, switch to the game, then use notification controls to select a target.");body.addView(status);
        heading(body,"SAFETY / PRIVACY",17,Color.WHITE,true);
        heading(body,"Screen frames are processed on-device only. There is no cloud upload, root access, game modification, anti-cheat bypass, or background startup. Stop the foreground capture at any time from the notification. Third-party overlays may be blocked or prohibited by games; use in permitted practice settings.",14,0xFFAFBAD5,false);
        setContentView(scroll);
    }
    private void heading(LinearLayout root,String txt,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(txt);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,5,0,16);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(t);}
    private void button(LinearLayout root,String title,Runnable action){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF203657));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=10;root.addView(b,lp);b.setOnClickListener(v->action.run());}
    private void command(String action){Intent i=new Intent(this,CaptureService.class);i.setAction(action);startService(i);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==CAPTURE_REQUEST){if(result==RESULT_OK && data!=null){Intent i=new Intent(this,CaptureService.class);i.setAction(CaptureService.ACTION_START);i.putExtra(CaptureService.EXTRA_RESULT,result);i.putExtra(CaptureService.EXTRA_DATA,data);startForegroundService(i);status.setText("Capture requested. Open your permitted test environment and select a target from the notification.");}else{status.setText("Capture permission declined.");}}}
}
