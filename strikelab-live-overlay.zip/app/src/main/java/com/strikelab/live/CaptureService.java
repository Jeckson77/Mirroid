package com.strikelab.live;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;

/** Explicitly user-started MediaProjection, tap-selected visual tracking with no automated input. */
public final class CaptureService extends Service {
    static final String ACTION_START="com.strikelab.live.START";
    static final String ACTION_STOP="com.strikelab.live.STOP";
    static final String ACTION_SELECT="com.strikelab.live.SELECT";
    static final String EXTRA_DATA="projection_data";
    static final String EXTRA_RESULT="projection_result";
    private static final String CHANNEL="strikelab_capture";
    private static final int NOTIFICATION=3071;
    private final TemplateTracker tracker=new TemplateTracker();
    private HandlerThread thread;
    private Handler worker;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private WindowManager windowManager;
    private WindowManager.LayoutParams overlayLayout;
    private TargetOverlay overlay;
    private boolean selecting,closing;
    private long lastFrame;
    private int captureWidth,captureHeight;
    @Override public void onCreate(){super.onCreate();
        windowManager=(WindowManager)getSystemService(WINDOW_SERVICE);
        thread=new HandlerThread("StrikeLabCapture");thread.start();worker=new Handler(thread.getLooper());
        NotificationChannel channel=new NotificationChannel(CHANNEL,"StrikeLab screen capture",NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?null:intent.getAction();
        if(ACTION_START.equals(action)){
            if(projection!=null)return START_NOT_STICKY;
            int result=intent.getIntExtra(EXTRA_RESULT,0);
            Intent data=(Intent)intent.getParcelableExtra(EXTRA_DATA);
            if(result!=android.app.Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY;}
            startForeground(NOTIFICATION,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            try{startCapture(result,data);}catch(Exception e){android.util.Log.e("StrikeLab","Capture initialization failed",e);stopSelf();}
        } else if(ACTION_STOP.equals(action)){stopSelf();}
        else if(projection!=null && ACTION_SELECT.equals(action)){chooseTarget();}
        else if(projection==null){stopSelf();}
        return START_NOT_STICKY;
    }
    private PendingIntent control(String action,int request){
        Intent i=new Intent(this,CaptureService.class);i.setAction(action);
        return PendingIntent.getService(this,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification notification(){
        return new Notification.Builder(this,CHANNEL)
            .setContentTitle("StrikeLab LIVE  •  capture active")
            .setContentText(selecting?"Tap a target on screen":"Visual tracking only — tap Stop to end")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(new Notification.Action.Builder(null,"Select target",control(ACTION_SELECT,1)).build())
            .addAction(new Notification.Action.Builder(null,"Stop",control(ACTION_STOP,3)).build())
            .build();
    }
    private void refreshNotification(){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION,notification());}
    private void startCapture(int result,Intent data){
        MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=manager.getMediaProjection(result,data);
        projection.registerCallback(new MediaProjection.Callback(){
            @Override public void onStop(){if(!closing)stopSelf();}
            @Override public void onCapturedContentResize(int w,int h){
                if(w>0&&h>0&&worker!=null)worker.post(()->resizeCapture(w,h));
            }
        },worker);
        Point size=new Point();windowManager.getDefaultDisplay().getRealSize(size);
        captureWidth=size.x;captureHeight=size.y;
        DisplayMetrics metrics=getResources().getDisplayMetrics();
        createReader(captureWidth,captureHeight);
        virtualDisplay=projection.createVirtualDisplay("StrikeLab capture",captureWidth,captureHeight,
            metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.getSurface(),null,worker);
        showOverlay();
        refreshNotification();
    }
    private void createReader(int w,int h){
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        reader.setOnImageAvailableListener(r->{
            Image frame=null;
            try{frame=r.acquireLatestImage();if(frame==null)return;
                long now=SystemClock.uptimeMillis();
                if(now-lastFrame<120)return;
                lastFrame=now;
                TemplateTracker.Result result=tracker.process(frame);
                TargetOverlay v=overlay;
                if(v!=null){
                    int screenW=v.getWidth(),screenH=v.getHeight();
                    if(screenW>0&&screenH>0){
                        final TemplateTracker.Result displayed=new TemplateTracker.Result(
                            result.x*screenW/frame.getWidth(),result.y*screenH/frame.getHeight(),result.quality,result.locked);
                        v.result(displayed);

                    }
                }
            }catch(Exception e){android.util.Log.w("StrikeLab","Frame processing issue",e);}
            finally{if(frame!=null)frame.close();}
        },worker);
    }
    private void resizeCapture(int w,int h){
        if(closing||virtualDisplay==null||(w==captureWidth&&h==captureHeight))return;
        captureWidth=w;captureHeight=h;tracker.clear();
        ImageReader old=reader;createReader(w,h);
        virtualDisplay.resize(w,h,getResources().getDisplayMetrics().densityDpi);
        virtualDisplay.setSurface(reader.getSurface());
        if(old!=null)old.close();
    }
    private void showOverlay(){
        overlay=new TargetOverlay(this,(nx,ny)->{
            tracker.select(nx,ny);
            selecting=false;
            if(overlay!=null)overlay.setChoosing(false);
            if(overlayLayout!=null){overlayLayout.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;windowManager.updateViewLayout(overlay,overlayLayout);}
            refreshNotification();
        });
        overlayLayout=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        overlayLayout.gravity=Gravity.TOP|Gravity.LEFT;
        windowManager.addView(overlay,overlayLayout);
    }
    private void chooseTarget(){
        selecting=true;tracker.clear();
        if(overlay!=null){overlay.setChoosing(true);
            overlayLayout.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            windowManager.updateViewLayout(overlay,overlayLayout);
        }
        refreshNotification();
    }
    @Override public void onConfigurationChanged(Configuration cfg){super.onConfigurationChanged(cfg);tracker.clear();}
    @Override public void onDestroy(){
        closing=true;tracker.clear();
        if(overlay!=null){try{windowManager.removeView(overlay);}catch(Exception ignored){}overlay=null;}
        if(virtualDisplay!=null){virtualDisplay.release();virtualDisplay=null;}
        if(reader!=null){reader.close();reader=null;}
        if(projection!=null){projection.stop();projection=null;}
        if(thread!=null){thread.quitSafely();thread=null;}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
