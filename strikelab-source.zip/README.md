# StrikeLab A55 — offline aim-training prototype

**An independent Android training tool** for studying your own Blood Strike practice-range screenshots and recordings. Not affiliated with or endorsed by Blood Strike or its publisher.

## What works

- Runs as an Android landscape app on the Samsung Galaxy A55 (Android 9+ supported).
- Shows the supplied practice-range screenshot immediately, with a head-target marker and alignment direction.
- Opens a screenshot from the device's file picker.
- Opens a video from the device's file picker and plays it locally.
- Allows pause, seek and tap-to-mark a mannequin's head.
- Follows that marked target across subsequent decoded video frames with a simple CPU image-template tracker.
- Displays an alignment line and relative left/right/up/down displacement.
- Does not need an internet connection, account, rooted device, accessibility permissions or storage permissions.

## What this is NOT

This is **not a live-match aimbot**. It has **no automatic enemy detection**, aim input injection, game process access, screen recording of other apps or control over Blood Strike. The template tracker requires you to manually select a head before tracking; it may lose the target during camera swings, occlusion or rapid movement. Do not interpret the confidence number as an AI prediction probability.

## How to use

1. Install the **debug** APK produced by Android Studio or the included Google Colab notebook.
2. Launch STRIKE LAB A55; your second supplied screenshot is already the default sample.
3. Tap the white mannequin's head to inspect visual alignment guidance.
4. Tap **OPEN VIDEO** and select the Blood Strike MP4 recording saved on the A55.
5. Press **PLAY**, pause when the mannequin is visible, then tap its head.
6. Press **PLAY** again to track it. If the marker drifts, pause and re-tap the target.

The overlay exists **inside this training app only**, never over the live game.

## Build with Google Colab (recommended)

1. Upload `StrikeLabA55-source.zip` using the file picker when the notebook asks.
2. Run every cell in `Build_StrikeLab_A55.ipynb` in a fresh Google Colab runtime.
3. Download `StrikeLabA55-debug.apk` from the final build cell.
4. Install using Android's normal APK installation flow. No root required.

Build requirements: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK 35, internet access in Colab for downloading build dependencies. The debug APK is signed with the normal development debug key.

**Development note:** Source was prepared and tested with a standalone synthetic Java tracker harness, but a complete Android Gradle build and physical A55 runtime test cannot be performed inside the current offline authoring environment.

## Local Android Studio build

Open the folder in Android Studio with JDK 17 configured and let Gradle sync, then choose *Build APK(s)*. Gradle wrapper files are not included; Android Studio or the Colab notebook supplies Gradle.

## Architecture

- `MainActivity.java`: Android player, media chooser, frame decoding, controls and threading.
- `AimOverlay.java`: aim cues over the app's own local playback surface.
- `TargetTracker.java`: manually initialized grayscale template matching; 480-pixel analysis frames.
- `app/src/main/assets/training_sample.jpg`: your supplied practice-range screenshot.

## Privacy

All processing stays on the device. The app requests no permissions and declares no internet permission. Media is selected through the Android Storage Access Framework file picker.
