package com.strikelab.a55;

import android.graphics.Bitmap;

/**
 * A user-initialized, CPU-only template tracker for OFFLINE practice recordings.
 * No game control, input injection, game memory access, network, or ML model.
 * The user must first mark the head; it is not an enemy detector.
 */
public final class TargetTracker {
    private static final int ANALYSIS_WIDTH = 480;
    private static final int RADIUS = 10;
    private static final int SEARCH = 45;
    private static final int SIZE = 2 * RADIUS + 1;
    private final int[] template = new int[SIZE * SIZE];
    private float x, y;
    private int frameWidth, frameHeight;
    private boolean initialized;

    public static final class Result {
        public final float xNorm, yNorm, confidence;
        public final boolean found;
        Result(float xNorm, float yNorm, float confidence, boolean found) {
            this.xNorm = xNorm;
            this.yNorm = yNorm;
            this.confidence = confidence;
            this.found = found;
        }
    }

    public synchronized void reset() { initialized = false; }

    public synchronized void initialize(Bitmap source, float xNorm, float yNorm) {
        Bitmap scaled = scale(source);
        frameWidth = scaled.getWidth();
        frameHeight = scaled.getHeight();
        int[] grays = gray(scaled);
        x = limit(Math.round(xNorm * frameWidth), RADIUS + 1, frameWidth - RADIUS - 2);
        y = limit(Math.round(yNorm * frameHeight), RADIUS + 1, frameHeight - RADIUS - 2);
        loadTemplate(grays, Math.round(x), Math.round(y));
        initialized = true;
        if (scaled != source) scaled.recycle();
    }

    public synchronized Result track(Bitmap source) {
        if (!initialized) return new Result(0, 0, 0, false);
        Bitmap scaled = scale(source);
        int width = scaled.getWidth(), height = scaled.getHeight();
        if (width != frameWidth || height != frameHeight) {
            if (scaled != source) scaled.recycle();
            return new Result(x / frameWidth, y / frameHeight, 0, false);
        }
        int[] grayscale = gray(scaled);
        if (scaled != source) scaled.recycle();

        int left = limit(Math.round(x) - SEARCH, RADIUS, width - RADIUS - 1);
        int right = limit(Math.round(x) + SEARCH, RADIUS, width - RADIUS - 1);
        int top = limit(Math.round(y) - SEARCH, RADIUS, height - RADIUS - 1);
        int bottom = limit(Math.round(y) + SEARCH, RADIUS, height - RADIUS - 1);

        long bestError = Long.MAX_VALUE;
        int bestX = Math.round(x), bestY = Math.round(y);
        for (int cy = top; cy <= bottom; cy += 2) {
            for (int cx = left; cx <= right; cx += 2) {
                long error = error(grayscale, cx, cy, bestError);
                if (error < bestError) { bestError = error; bestX = cx; bestY = cy; }
            }
        }
        // Pixel-level refinement around the best coarse position.
        for (int cy = Math.max(RADIUS, bestY - 2); cy <= Math.min(height - RADIUS - 1, bestY + 2); cy++) {
            for (int cx = Math.max(RADIUS, bestX - 2); cx <= Math.min(width - RADIUS - 1, bestX + 2); cx++) {
                long error = error(grayscale, cx, cy, bestError);
                if (error < bestError) { bestError = error; bestX = cx; bestY = cy; }
            }
        }
        double rms = Math.sqrt(bestError / (double) (SIZE * SIZE));
        float confidence = (float) Math.max(0.0, Math.min(1.0, 1.0 - rms / 75.0));
        boolean found = confidence >= 0.42f;
        if (found) {
            // Light smoothing keeps the marker legible, without altering gameplay.
            x = 0.45f * x + 0.55f * bestX;
            y = 0.45f * y + 0.55f * bestY;
        }
        return new Result(x / frameWidth, y / frameHeight, confidence, found);
    }

    private Bitmap scale(Bitmap source) {
        int scaledHeight = Math.max(40, Math.round(source.getHeight() *
                (ANALYSIS_WIDTH / (float) source.getWidth())));
        if (source.getWidth() == ANALYSIS_WIDTH && source.getHeight() == scaledHeight) return source;
        return Bitmap.createScaledBitmap(source, ANALYSIS_WIDTH, scaledHeight, true);
    }

    private static int limit(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private int[] gray(Bitmap bitmap) {
        int[] argb = new int[frameWidth * frameHeight];
        bitmap.getPixels(argb, 0, frameWidth, 0, 0, frameWidth, frameHeight);
        int[] grays = new int[argb.length];
        for (int i = 0; i < argb.length; i++) {
            int p = argb[i];
            grays[i] = ((p >> 16 & 255) * 77 + (p >> 8 & 255) * 150 + (p & 255) * 29) >> 8;
        }
        return grays;
    }

    private void loadTemplate(int[] pixels, int cx, int cy) {
        int k = 0;
        for (int j = -RADIUS; j <= RADIUS; j++)
            for (int i = -RADIUS; i <= RADIUS; i++)
                template[k++] = pixels[(cy + j) * frameWidth + cx + i];
    }

    private long error(int[] pixels, int cx, int cy, long earlyLimit) {
        long total = 0;
        int k = 0;
        for (int j = -RADIUS; j <= RADIUS; j++) {
            int row = (cy + j) * frameWidth + cx - RADIUS;
            for (int i = 0; i < SIZE; i++) {
                int diff = pixels[row + i] - template[k++];
                total += diff * diff;
            }
            if (total > earlyLimit) break;
        }
        return total;
    }
}
