package com.strikelab.a55;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.VideoView;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * STRIKE LAB A55: offline video/image aim training. Never captures another app,
 * controls a game, injects touches, reads process memory, or uses network access.
 */
public final class MainActivity extends Activity {
    private static final int PICK_MEDIA = 33;
    private static final int BG = 0xFF080F1C;
    private static final int CYAN = 0xFF34D5F3;
    private static final int GOLD = 0xFFFFC857;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService decoder = Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private final Object retrieverLock = new Object();
    private final TargetTracker tracker = new TargetTracker();
    private MediaMetadataRetriever retriever;
    private ImageView still;
    private VideoView movie;
    private AimOverlay overlay;
    private TextView status, modeLabel;
    private TextView playButton;
    private SeekBar timeline;
    private Bitmap currentImage;
    private boolean videoMode = false, hasTarget = false, touchingTimeline = false;
    private int videoWidth = 2340, videoHeight = 1080;
    private int pickMode = 0;
    private float selectedX, selectedY;
    private final Runnable updater = new Runnable() {
        @Override public void run() {
            if (videoMode && movie != null) {
                int duration = movie.getDuration();
                if (duration > 0 && !touchingTimeline) {
                    timeline.setMax(duration);
                    timeline.setProgress(movie.getCurrentPosition());
                }
                if (movie.isPlaying() && hasTarget && !busy.getAndSet(true)) {
                    int atMs=movie.getCurrentPosition();
                    decoder.execute(() -> {
                        TargetTracker.Result result = null;
                        try {
                            Bitmap frame=frameAt(atMs);
                            if (frame != null) {
                                result=tracker.track(frame);
                                frame.recycle();
                            }
                        } catch (Exception ignored) { }
                        TargetTracker.Result ready=result;
                        ui.post(() -> {
                            busy.set(false);
                            if (!videoMode || !hasTarget) return;
                            if (ready != null) {
                                overlay.updateTarget(ready.xNorm,ready.yNorm,ready.found,ready.confidence);
                                setTrackingStatus(ready);
                            }
                        });
                    });
                }
            }
            ui.postDelayed(this, 350);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildScreen();
        loadSample();
        ui.postDelayed(updater, 500);
    }

    private void buildScreen() {
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        still=new ImageView(this);
        still.setScaleType(ImageView.ScaleType.FIT_CENTER);
        still.setBackgroundColor(BG);
        movie=new VideoView(this);
        movie.setBackgroundColor(Color.TRANSPARENT);
        movie.setVisibility(View.GONE);
        root.addView(still,new FrameLayout.LayoutParams(-1,-1));
        root.addView(movie,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        overlay=new AimOverlay(this);
        root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        overlay.setSelectionListener(this::selectTarget);

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18),dp(7),dp(12),dp(7));
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setBackgroundColor(0xE6091425);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,dp(48),Gravity.TOP);
        root.addView(top,tp);
        TextView logo=new TextView(this);
        logo.setText("◎   STRIKE LAB  /  A55");
        logo.setTextColor(CYAN); logo.setTextSize(15); logo.setTypeface(null,1);
        top.addView(logo,new LinearLayout.LayoutParams(0,-2,1));
        modeLabel=new TextView(this);
        modeLabel.setText("OFFLINE  •  PHOTO PRACTICE");
        modeLabel.setTextColor(0xFFDCE8F7); modeLabel.setTextSize(11);
        top.addView(modeLabel);

        LinearLayout bottom=new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(12),dp(8),dp(12),dp(9));
        bottom.setBackgroundColor(0xE9091425);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        root.addView(bottom,bp);
        status=new TextView(this);
        status.setTextColor(0xFFD6ECF7);
        status.setTextSize(12);
        status.setText("Tap a mannequin's head to mark a training target.");
        bottom.addView(status);

        timeline=new SeekBar(this);
        timeline.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        timeline.setThumbTintList(android.content.res.ColorStateList.valueOf(GOLD));
        timeline.setVisibility(View.GONE);
        bottom.addView(timeline,new LinearLayout.LayoutParams(-1,dp(24)));
        timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar sb) { touchingTimeline=true; }
            @Override public void onProgressChanged(SeekBar sb,int progress,boolean user) { }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                if (videoMode) { movie.seekTo(sb.getProgress()); resetTarget(); }
                touchingTimeline=false;
            }
        });

        LinearLayout actions=new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0,dp(5),0,0);
        bottom.addView(actions);
        addButton(actions,"SAMPLE",() -> loadSample(),false);
        addButton(actions,"OPEN IMAGE",() -> openFile(false),false);
        addButton(actions,"OPEN VIDEO",() -> openFile(true),true);
        playButton=addButton(actions,"PLAY",this::togglePlayback,false);
        addButton(actions,"+1 SEC",this::skipForward,false);
        addButton(actions,"RESET TARGET",this::resetTarget,false);

        movie.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            videoWidth=mp.getVideoWidth()>0 ? mp.getVideoWidth() : videoWidth;
            videoHeight=mp.getVideoHeight()>0 ? mp.getVideoHeight() : videoHeight;
            overlay.setSourceSize(videoWidth,videoHeight);
            movie.pause();
            movie.seekTo(0);
            playButton.setText("PLAY");
            status.setText("Play to find a mannequin, pause, then tap its head. Press PLAY to track.");
        });
        movie.setOnCompletionListener(mp -> {
            playButton.setText("REPLAY");
            status.setText("Recording complete. Replay or open another recording.");
        });
        movie.setOnErrorListener((mp,what,extra) -> {
            status.setText("Unable to play this recording. Try an MP4 from your phone.");
            return true;
        });
    }

    private TextView addButton(LinearLayout parent,String title,Runnable action,boolean bright) {
        TextView v=new TextView(this);
        v.setText(title); v.setTextSize(10); v.setTextColor(bright?BG:0xFFE1F5FA);
        v.setTypeface(null,1); v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10),0,dp(10),0);
        GradientDrawable shape=new GradientDrawable();
        shape.setColor(bright?CYAN:0xFF18324A);
        shape.setCornerRadius(dp(7));
        v.setBackground(shape);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(31),1);
        lp.setMargins(dp(3),0,dp(3),0);
        parent.addView(v,lp);
        v.setOnClickListener(a -> action.run());
        return v;
    }

    private void loadSample() {
        resetTarget(); videoMode=false; movie.stopPlayback(); movie.setVisibility(View.GONE);
        still.setVisibility(View.VISIBLE);
        timeline.setVisibility(View.GONE);
        modeLabel.setText("OFFLINE  •  PHOTO PRACTICE");
        try(InputStream input=getAssets().open("training_sample.jpg")) {
            currentImage=BitmapFactory.decodeStream(input);
            still.setImageBitmap(currentImage);
            overlay.setSourceSize(currentImage.getWidth(),currentImage.getHeight());
            status.setText("Your Blood Strike screenshot is loaded. Tap the white mannequin's HEAD.");
        } catch(Exception e) { status.setText("Could not open sample image."); }
    }

    private void openFile(boolean video) {
        pickMode=video?1:0;
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(video?"video/*":"image/*");
        startActivityForResult(intent,PICK_MEDIA);
    }

    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=PICK_MEDIA || result!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        resetTarget();
        if(pickMode==1) {
            videoMode=true;
            still.setVisibility(View.GONE); movie.setVisibility(View.VISIBLE);
            timeline.setVisibility(View.VISIBLE);
            modeLabel.setText("OFFLINE  •  VIDEO TRACKER");
            synchronized(retrieverLock) {
                if(retriever!=null) { try { retriever.release(); } catch(Exception ignored) {} }
                retriever=new MediaMetadataRetriever();
                try { retriever.setDataSource(this,uri); }
                catch(Exception e) { status.setText("This video cannot be read."); retriever=null; }
            }
            movie.setVideoURI(uri);
        } else {
            videoMode=false; movie.stopPlayback(); movie.setVisibility(View.GONE);
            still.setVisibility(View.VISIBLE); timeline.setVisibility(View.GONE);
            modeLabel.setText("OFFLINE  •  PHOTO PRACTICE");
            try(InputStream stream=getContentResolver().openInputStream(uri)) {
                currentImage=BitmapFactory.decodeStream(stream);
                if(currentImage==null) throw new IllegalArgumentException();
                still.setImageBitmap(currentImage);
                overlay.setSourceSize(currentImage.getWidth(),currentImage.getHeight());
                status.setText("Tap the target's head to show aim-alignment guidance.");
            } catch(Exception e) { status.setText("Unable to read this image."); }
        }
    }

    private void selectTarget(float x,float y) {
        selectedX=x; selectedY=y;
        overlay.updateTarget(x,y,true,1f);
        hasTarget=true;
        if(!videoMode) {
            showOffsets(x,y,1f);
            return;
        }
        movie.pause(); playButton.setText("PLAY");
        int position=movie.getCurrentPosition();
        status.setText("Setting target... keep the mannequin visible in this frame.");
        decoder.execute(() -> {
            try {
                Bitmap frame=frameAt(position);
                if(frame == null) throw new IllegalStateException("frame unavailable");
                tracker.initialize(frame,x,y);
                frame.recycle();
                ui.post(() -> status.setText("Target calibrated. Tap PLAY to track. Re-tap if tracking drifts."));
            } catch(Exception e) {
                ui.post(() -> status.setText("Could not initialize tracking here. Seek to a clearer frame."));
            }
        });
    }

    private Bitmap frameAt(int milliseconds) {
        synchronized(retrieverLock) {
            if(retriever==null) return null;
            try {
                return retriever.getScaledFrameAtTime(Math.max(0,milliseconds)*1000L,
                        MediaMetadataRetriever.OPTION_CLOSEST,480,
                        Math.max(40,Math.round(videoHeight*480f/videoWidth)));
            } catch(Exception e) { return null; }
        }
    }

    private void setTrackingStatus(TargetTracker.Result r) {
        if(r.found) showOffsets(r.xNorm,r.yNorm,r.confidence);
        else status.setText("TRACK LOST  •  Pause and tap the head again to recalibrate.");
    }
    private void showOffsets(float x,float y,float confidence) {
        float dx=(x-.5f)*100f, dy=(y-.5f)*100f;
        String h=dx>1?"RIGHT":dx< -1?"LEFT":"CENTER";
        String v=dy>1?"DOWN":dy< -1?"UP":"CENTER";
        status.setText(String.format(Locale.US,
                "TARGET %d%%  •  Correction: %s %.1f%% / %s %.1f%%  •  Visual practice only",
                Math.round(confidence*100),h,Math.abs(dx),v,Math.abs(dy)));
    }
    private void resetTarget() {
        hasTarget=false; tracker.reset();
        if(overlay!=null) overlay.clearTarget();
        if(status!=null) status.setText("Tap a mannequin's head to select the practice target.");
    }
    private void togglePlayback() {
        if(!videoMode) { status.setText("OPEN VIDEO to track a moving target from a recording."); return; }
        if(movie.isPlaying()) {
            movie.pause(); playButton.setText("PLAY");
            status.setText("Paused. Tap a mannequin's head to calibrate tracking.");
        } else {
            if(movie.getDuration()>0 && movie.getCurrentPosition()>=movie.getDuration()-200) {
                movie.seekTo(0); resetTarget();
            }
            movie.start(); playButton.setText("PAUSE");
            if(!hasTarget) status.setText("Pause when an enemy is visible, then tap its head.");
        }
    }
    private void skipForward() {
        if(!videoMode) { status.setText("Open a video to skip frames."); return; }
        movie.seekTo(Math.min(movie.getDuration(),movie.getCurrentPosition()+1000));
        resetTarget();
        status.setText("Skipped 1 second. Re-select target to keep tracking accurate.");
    }
    private int dp(float value) { return Math.round(value*getResources().getDisplayMetrics().density); }
    @Override protected void onDestroy() {
        ui.removeCallbacks(updater); decoder.shutdownNow();
        synchronized(retrieverLock) {
            if(retriever!=null) { try { retriever.release(); } catch(Exception ignored) { } retriever=null; }
        }
        super.onDestroy();
    }
}
