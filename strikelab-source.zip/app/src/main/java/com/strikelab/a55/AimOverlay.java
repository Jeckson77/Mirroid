package com.strikelab.a55;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.Locale;

/** Draws aim-training cues over the app's own image or video player. */
public final class AimOverlay extends View {
    public interface TargetSelection { void onSelect(float xNorm, float yNorm); }
    private TargetSelection callback;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final int CYAN = Color.rgb(52, 213, 243);
    private static final int GOLD = Color.rgb(255, 204, 88);
    private final RectF videoRect = new RectF();
    private int sourceW = 1536, sourceH = 709;
    private float xNorm = 0.5f, yNorm = 0.5f;
    private boolean hasTarget = false, tracking = false;
    private float confidence = 0;

    public AimOverlay(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    public void setSelectionListener(TargetSelection listener) { callback = listener; }
    public void setSourceSize(int w, int h) { sourceW = Math.max(1,w); sourceH=Math.max(1,h); invalidate(); }
    public void clearTarget() { hasTarget=false; tracking=false; confidence=0; invalidate(); }
    public void updateTarget(float x, float y, boolean locked, float score) {
        xNorm = x; yNorm = y; hasTarget = true; tracking = locked; confidence = score; invalidate();
    }
    private RectF content() {
        float s = Math.min(getWidth()/(float)sourceW, getHeight()/(float)sourceH);
        float w = sourceW*s, h=sourceH*s;
        videoRect.set((getWidth()-w)/2f, (getHeight()-h)/2f,
                (getWidth()+w)/2f, (getHeight()+h)/2f);
        return videoRect;
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        RectF r=content();
        float cx=r.centerX(), cy=r.centerY();
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.3f)); p.setColor(0xAAFFFFFF);
        c.drawCircle(cx,cy,dp(6),p);
        c.drawLine(cx-dp(15),cy,cx-dp(9),cy,p);
        c.drawLine(cx+dp(9),cy,cx+dp(15),cy,p);
        c.drawLine(cx,cy-dp(15),cx,cy-dp(9),p);
        c.drawLine(cx,cy+dp(9),cx,cy+dp(15),p);
        if (!hasTarget) return;

        float tx=r.left+r.width()*xNorm, ty=r.top+r.height()*yNorm;
        int active=tracking?CYAN:GOLD;
        float radius=dp(21);
        p.setColor(active); p.setStrokeWidth(dp(1.9f)); p.setStyle(Paint.Style.STROKE);
        c.drawCircle(tx,ty,radius,p);
        c.drawLine(tx-radius-dp(7),ty,tx-radius+dp(2),ty,p);
        c.drawLine(tx+radius-dp(2),ty,tx+radius+dp(7),ty,p);
        c.drawLine(tx,ty-radius-dp(7),tx,ty-radius+dp(2),p);
        c.drawLine(tx,ty+radius-dp(2),tx,ty+radius+dp(7),p);
        p.setColor(0xBFFFFFFF); p.setStrokeWidth(dp(1));
        c.drawLine(cx,cy,tx,ty,p);
        p.setStyle(Paint.Style.FILL); p.setColor(active); c.drawCircle(tx,ty,dp(2.8f),p);
        p.setColor(0xDD0D1C30);
        RectF label=new RectF(tx+dp(22),ty-dp(29),tx+dp(138),ty-dp(6));
        if(label.right > getWidth()-dp(8)) label.offset(-dp(167),0);
        c.drawRoundRect(label,dp(5),dp(5),p);
        p.setTextSize(dp(11)); p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",1));
        p.setColor(active);
        String tag=tracking ? String.format(Locale.US,"TRACK  %d%%",Math.round(confidence*100)) : "SELECTED / LOST";
        c.drawText(tag,label.left+dp(7),label.top+dp(15),p);
    }
    private float dp(float value) { return value*getResources().getDisplayMetrics().density; }
    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) {
            RectF r=content();
            float x=e.getX(),y=e.getY();
            if (r.contains(x,y) && callback!=null) {
                callback.onSelect((x-r.left)/r.width(),(y-r.top)/r.height());
            }
            performClick();
            return true;
        }
        return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }
}
