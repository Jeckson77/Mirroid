# StrikeLab A55 — GitHub Actions APK build

This repository holds the **offline aim-training / recorded-gameplay target tracker**, not a live-match aimbot. No input injection or live game control.

## Automated build

Every push to `main` that changes the Android app or workflow starts **Build StrikeLab A55 APK**. Alternatively go to **Actions → Build StrikeLab A55 APK → Run workflow**.

1. Wait for a **green check** on the workflow run (success is not guaranteed until the run completes).
2. Open the run → **Artifacts** → **StrikeLabA55-debug-apk** and download.
3. Extract the downloaded artifact ZIP, open `app-debug.apk` on your Android device, and approve installation from the source if prompted.

APK application ID: `com.strikelab.a55`; built with JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK 35.

The APK is debug-signed. Install this build only on your own device; do not upload a debug APK to public stores. Do not share signing keys.

## Source

Open `README.md` for usage. The app can load a screenshot or MP4 video, accept a manual head target selection, and draw training feedback in its own app window.
