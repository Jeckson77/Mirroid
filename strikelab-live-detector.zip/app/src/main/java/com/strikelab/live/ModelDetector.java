package com.strikelab.live;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.RectF;

import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.Detection;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult;

import java.util.ArrayList;
import java.util.List;

/** General COCO person detector. Not able to determine teammates vs opponents. */
public final class ModelDetector implements AutoCloseable {
    public static final class Target {
        public final RectF rect;
        public final float confidence;
        public final float headX,headY;
        public Target(RectF box,float confidence){
            this.rect=new RectF(box);this.confidence=confidence;
            this.headX=box.centerX();this.headY=box.top+box.height()*0.18f;
        }
    }
    private final ObjectDetector detector;
    public ModelDetector(Context context){
        BaseOptions base=BaseOptions.builder().setModelAssetPath("efficientdet_lite0.tflite").build();
        ObjectDetector.ObjectDetectorOptions options=ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(base).setRunningMode(RunningMode.IMAGE)
            .setScoreThreshold(0.23f).setMaxResults(12).build();
        detector=ObjectDetector.createFromOptions(context,options);
    }
    public List<Target> find(Bitmap frame){
        MPImage image=new BitmapImageBuilder(frame).build();
        ObjectDetectorResult result=detector.detect(image);
        ArrayList<Target> out=new ArrayList<>();
        for(Detection d:result.detections()){
            if(d.categories().isEmpty())continue;
            Category c=d.categories().get(0);
            String label=c.categoryName();
            if(!label.equalsIgnoreCase("person"))continue;
            RectF box=d.boundingBox();
            if(box.width()<6||box.height()<8)continue;
            out.add(new Target(box,c.score()));
        }
        return out;
    }
    @Override public void close(){ detector.close(); }
}
