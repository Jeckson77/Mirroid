package com.strikelab.live;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Visible, pass-through heads-up overlay. Does not send any input to the game. */
public final class TargetOverlay extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<TargetRanker.Candidate> candidates=new ArrayList<>();
    private float targetX,targetY;private boolean locked;
    private String state="INITIALIZING DETECTOR";
    public TargetOverlay(Context context){super(context);setBackgroundColor(Color.TRANSPARENT);}
    public void display(List<TargetRanker.Candidate> list,TargetRanker.Candidate chosen,String status){
        post(()->{
            candidates.clear();candidates.addAll(list);
            locked=chosen!=null;
            if(locked){targetX=chosen.cx();targetY=chosen.headY();}
            state=status;
            invalidate();
        });
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float w=getWidth(),h=getHeight();
        if(w<1||h<1)return;
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFFE9F8FF);
        paint.setTextSize(Math.max(15,Math.min(w,h)*.024f));
        canvas.drawText("STRIKELAB · LIVE DETECTION",w*.015f,h*.08f,paint);
        paint.setTextSize(Math.max(12,Math.min(w,h)*.019f));
        canvas.drawText(state,w*.015f,h*.125f,paint);
        paint.setStrokeWidth(Math.max(1.5f,h*.003f));paint.setStyle(Paint.Style.STROKE);
        for(TargetRanker.Candidate c:candidates){
            paint.setColor(0xAAFFCC55);
            canvas.drawRect(c.left*w,c.top*h,c.right*w,c.bottom*h,paint);
            canvas.drawCircle(c.cx()*w,c.headY()*h,Math.max(5,h*.01f),paint);
        }
        if(locked){
            paint.setColor(0xFF4CC9F0);
            canvas.drawCircle(targetX*w,targetY*h,Math.max(11,h*.024f),paint);
            float gap=Math.max(13,h*.025f);
            canvas.drawLine(targetX*w-gap*2,targetY*h,targetX*w-gap, targetY*h,paint);
            canvas.drawLine(targetX*w+gap,targetY*h,targetX*w+gap*2,targetY*h,paint);
            canvas.drawLine(targetX*w,targetY*h-gap*2,targetX*w,targetY*h-gap,paint);
            canvas.drawLine(targetX*w,targetY*h+gap,targetX*w,targetY*h+gap*2,paint);
        }
    }
}
