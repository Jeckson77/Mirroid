package com.strikelab.live;

import java.util.List;

/** Pure selection and smoothing logic for person candidates, independently unit testable. */
public final class TargetRanker {
    public static final class Candidate {
        public final float left, top, right, bottom, confidence;
        public Candidate(float left,float top,float right,float bottom,float confidence) {
            this.left=left;this.top=top;this.right=right;this.bottom=bottom;this.confidence=confidence;
        }
        public float cx(){return (left+right)*.5f;}
        public float headY(){return top+(bottom-top)*.18f;}
    }
    private float selectedX=.5f, selectedY=.5f;
    private boolean wasTracking;
    public Candidate select(List<Candidate> candidates) {
        Candidate best=null;float bestScore=-999f;
        for(Candidate c : candidates){
            if(c.confidence < .22f || c.left<0 || c.right>1.01f || c.top<0 || c.bottom>1.01f || c.right<=c.left || c.bottom<=c.top)continue;
            float size=(c.right-c.left)*(c.bottom-c.top);
            if(size < .00022f)continue;
            float dx=c.cx()-.5f,dy=c.headY()-.5f;
            float reticleDistance=(float)Math.sqrt(dx*dx+dy*dy);
            float score=c.confidence*.70f-reticleDistance*.8f;
            if(wasTracking){
                float sdx=c.cx()-selectedX,sdy=c.headY()-selectedY;
                float continuity=(float)Math.sqrt(sdx*sdx+sdy*sdy);
                score+=.42f*Math.max(0,1-continuity*5);
            }
            if(score>bestScore){bestScore=score;best=c;}
        }
        if(best!=null){
            selectedX=best.cx();selectedY=best.headY();wasTracking=true;
        }else{wasTracking=false;}
        return best;
    }
    public void clear(){wasTracking=false;selectedX=.5f;selectedY=.5f;}
}
