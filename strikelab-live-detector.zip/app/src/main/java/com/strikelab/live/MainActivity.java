package com.strikelab.live;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int CAPTURE=137;
    private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},41);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xFF0C1323);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,45,32,30);scroll.addView(root);
        label(root,"STRIKELAB / LIVE DETECTOR",26,0xFF5BD6FF,true);
        label(root,"Samsung Galaxy A55 · version 0.4.0",14,0xFFA8B8D3,false);
        label(root,"Detect possible characters on screen and mark a selected target",19,Color.WHITE,true);
        label(root,"Works with screen sharing permissions. Uses an offline general person detector, not a Blood Strike-specific enemy/team classifier. No automatic aim movement or firing control.",15,0xFFD5DFEC,false);
        button(root,"1. Grant floating display permission",()->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        button(root,"2. Start live detection",()->{
            if(!Settings.canDrawOverlays(this)){status.setText("Enable floating overlay permission first.");return;}
            MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            Intent request=Build.VERSION.SDK_INT>=34?mgr.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay()):mgr.createScreenCaptureIntent();
            startActivityForResult(request,CAPTURE);
        });
        button(root,"Stop screen analysis",()->{
            Intent stop=new Intent(this,CaptureService.class).setAction(CaptureService.ACTION_STOP);startService(stop);
            status.setText("Stop requested. The screen overlay should disappear.");
        });
        status=new TextView(this);status.setTextSize(16);status.setTextColor(0xFF8CDCF6);status.setPadding(0,18,0,26);
        status.setText("Give permission, switch to your permitted screen, and watch the visual candidate boxes. Stop from the ongoing notification.");root.addView(status);
        label(root,"Important limitations",19,Color.WHITE,true);
        label(root,"Android and games can block capture or overlays. The app cannot distinguish opponents from teammates, cannot lock game aim, and is not tested on your A55. It processes frames locally; no uploaded gameplay or network permissions.",14,0xFFA8B8D3,false);
        setContentView(scroll);
    }
    private void label(LinearLayout parent,String s,int size,int color,boolean strong){
        TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(size);v.setPadding(0,6,0,17);
        if(strong)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);parent.addView(v);
    }
    private void button(LinearLayout parent,String name,Runnable action){
        Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(ColorStateList.valueOf(0xFF1E4263));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=12;parent.addView(b,p);
        b.setOnClickListener(v->action.run());
    }
    @Override protected void onActivityResult(int code,int result,Intent data){super.onActivityResult(code,result,data);
        if(code==CAPTURE){
            if(result==RESULT_OK&&data!=null){
                Intent svc=new Intent(this,CaptureService.class).setAction(CaptureService.ACTION_START);
                svc.putExtra(CaptureService.EXTRA_RESULT,result);svc.putExtra(CaptureService.EXTRA_DATA,data);
                startForegroundService(svc);status.setText("Capture enabled. Switch to the game or permitted test screen.");
            }else status.setText("Screen capture permission declined.");
        }
    }
}
