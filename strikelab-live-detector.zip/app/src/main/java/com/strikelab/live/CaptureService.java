package com.strikelab.live;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.RectF;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** Consented live frame analysis; no touch injection and no game modification. */
public final class CaptureService extends Service {
    static final String ACTION_START="com.strikelab.live.START";
    static final String ACTION_STOP="com.strikelab.live.STOP";
    static final String EXTRA_DATA="projection_data";
    static final String EXTRA_RESULT="projection_result";
    private static final String CHANNEL="strikelab_detector";
    private static final int NOTIFICATION=4071;
    private static final long MIN_INTERVAL_MS=260;
    private static final int MAX_FRAME_WIDTH=960;
    private HandlerThread thread;
    private Handler worker;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private ModelDetector model;
    private TargetRanker ranker=new TargetRanker();
    private WindowManager windows;
    private TargetOverlay overlay;
    private long lastFrame=0;
    private boolean closing=false;
    private int captureW,captureH;
    private volatile boolean modelFailed=false;
    private int frames=0;
    private long started;

    @Override public void onCreate(){super.onCreate();
        windows=(WindowManager)getSystemService(WINDOW_SERVICE);
        thread=new HandlerThread("StrikeLabDetection");thread.start();worker=new Handler(thread.getLooper());
        NotificationChannel channel=new NotificationChannel(CHANNEL,"StrikeLab live screen analysis",NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }
    private Notification notification(){
        Intent stop=new Intent(this,CaptureService.class).setAction(ACTION_STOP);
        PendingIntent pending=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,CHANNEL)
            .setContentTitle("StrikeLab — live detector")
            .setContentText("Screen analysis active · use Stop to end")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(new Notification.Action.Builder(null,"Stop",pending).build())
            .build();
    }
    @Override public int onStartCommand(Intent input,int flags,int startId){
        String action=input==null?null:input.getAction();
        if(ACTION_STOP.equals(action)){stopSelf();return START_NOT_STICKY;}
        if(ACTION_START.equals(action)&&projection==null){
            int result=input.getIntExtra(EXTRA_RESULT,0);
            Intent grant=(Intent)input.getParcelableExtra(EXTRA_DATA);
            if(result!=Activity.RESULT_OK||grant==null){stopSelf();return START_NOT_STICKY;}
            startForeground(NOTIFICATION,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            try{startCapture(result,grant);}catch(Exception e){Log.e("StrikeLab","Unable to start capture",e);stopSelf();}
        }
        return START_NOT_STICKY;
    }
    private void startCapture(int result,Intent grant){
        // The detector is constructed on the same worker that owns all subsequent inference.
        worker.post(()->{
            try{model=new ModelDetector(getApplicationContext());}
            catch(Exception e){modelFailed=true;Log.e("StrikeLab","Person detector unavailable",e);postStatus("MODEL FAILED · check log");}
        });
        MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=manager.getMediaProjection(result,grant);
        projection.registerCallback(new MediaProjection.Callback(){
            @Override public void onStop(){if(!closing)stopSelf();}
            @Override public void onCapturedContentResize(int w,int h){if(w>0&&h>0&&worker!=null)worker.post(()->resize(w,h));}
        },worker);
        Point screen=new Point();windows.getDefaultDisplay().getRealSize(screen);
        captureW=screen.x;captureH=screen.y;
        setupReader(captureW,captureH);
        DisplayMetrics dm=getResources().getDisplayMetrics();
        display=projection.createVirtualDisplay("StrikeLabScreen",captureW,captureH,dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,worker);
        overlay=new TargetOverlay(this);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;
        windows.addView(overlay,p);
        started=SystemClock.uptimeMillis();
    }
    private void postStatus(String message){
        if(overlay!=null)overlay.display(new ArrayList<>(),null,message);
    }
    private void setupReader(int w,int h){
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        reader.setOnImageAvailableListener(r->{
            Image frame=null;
            try{
                frame=r.acquireLatestImage();if(frame==null)return;
                long now=SystemClock.uptimeMillis();
                if(now-lastFrame<MIN_INTERVAL_MS)return;
                lastFrame=now;
                if(model==null){postStatus(modelFailed?"DETECTOR UNAVAILABLE":"LOADING AI MODEL …");return;}
                Bitmap smaller=toBitmap(frame);
                if(smaller==null)return;
                List<ModelDetector.Target> detections;
                try{detections=model.find(smaller);}finally{smaller.recycle();}
                ArrayList<TargetRanker.Candidate> candidates=new ArrayList<>();
                int inW=frame.getWidth(),inH=frame.getHeight();
                // Model coordinates are in scaled image pixels; preserve correct aspect ratio.
                int scaledW=Math.min(inW,MAX_FRAME_WIDTH);
                int scaledH=Math.max(1,Math.round((float)inH*scaledW/inW));
                for(ModelDetector.Target target:detections){
                    RectF box=target.rect;
                    candidates.add(new TargetRanker.Candidate(
                        clamp(box.left/scaledW),clamp(box.top/scaledH),
                        clamp(box.right/scaledW),clamp(box.bottom/scaledH),target.confidence));
                }
                TargetRanker.Candidate selected=ranker.select(candidates);
                frames++;
                int rate=(int)Math.round(frames*1000.0/Math.max(1,now-started));
                if(overlay!=null)overlay.display(candidates,selected,
                    selected==null ? "NO PERSON CANDIDATES · "+rate+" fps" :
                    "PERSON CANDIDATES "+candidates.size()+" · "+rate+" fps · NOT TEAM CLASSIFIED");
            }catch(Throwable e){Log.w("StrikeLab","Frame processing failed",e);postStatus("FRAME ERROR · see Android log");}
            finally{if(frame!=null)frame.close();}
        },worker);
    }
    private static float clamp(float n){return Math.max(0,Math.min(1,n));}
    private Bitmap toBitmap(Image image){
        int w=image.getWidth(),h=image.getHeight();
        Image.Plane plane=image.getPlanes()[0];
        ByteBuffer pixels=plane.getBuffer();pixels.rewind();
        int strideWidth=plane.getRowStride()/plane.getPixelStride();
        if(strideWidth<w)return null;
        Bitmap padded=Bitmap.createBitmap(strideWidth,h,Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(pixels);
        Bitmap crop=strideWidth==w?padded:Bitmap.createBitmap(padded,0,0,w,h);
        if(crop!=padded)padded.recycle();
        int scaledW=Math.min(w,MAX_FRAME_WIDTH);
        int scaledH=Math.max(1,Math.round((float)h*scaledW/w));
        Bitmap scaled=Bitmap.createScaledBitmap(crop,scaledW,scaledH,true);
        if(scaled!=crop)crop.recycle();
        return scaled;
    }
    private void resize(int w,int h){
        if(closing||display==null||(w==captureW&&h==captureH))return;
        captureW=w;captureH=h;ranker.clear();
        ImageReader old=reader;setupReader(w,h);
        display.resize(w,h,getResources().getDisplayMetrics().densityDpi);
        display.setSurface(reader.getSurface());
        if(old!=null)old.close();
    }
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);ranker.clear();}
    @Override public void onDestroy(){
        closing=true;
        if(overlay!=null){try{windows.removeView(overlay);}catch(Exception ignored){}overlay=null;}
        if(display!=null){display.release();display=null;}
        if(reader!=null){reader.close();reader=null;}
        if(projection!=null){projection.stop();projection=null;}
        if(worker!=null){worker.post(()->{if(model!=null){model.close();model=null;}});}
        if(thread!=null){thread.quitSafely();thread=null;}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
