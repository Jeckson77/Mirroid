# StrikeLab A55 — In-Game Screen Detector (Experimental)

This Android application uses a foreground MediaProjection session and MediaPipe EfficientDet Lite0 to identify **general person candidates** in a user's actively shared display. It draws non-interactive bounding boxes and highlights the head region of the highest-scoring candidate, weighted toward the reticle and continuity.

## Capabilities

- On-device visual person detection in consented live screen frames.
- Floating, touch-pass-through bounding boxes and head guidance. Notification stop control.
- Stable target candidate selection while the screen rotates, with a 260 ms frame-analysis interval.
- No network permission, no remote frame uploads, no game memory access.

## Boundaries

- **Not a functional aimbot.** It does not inject input, move the crosshair, hold Fire, or recognize opponents versus teammates. Android AccessibilityService gesture injection cancels a user's ongoing touch, so it cannot reliably deliver the requested simultaneous Fire + aim behavior through ordinary Android permissions.
- General EfficientDet Lite0 is not tuned for Blood Strike character art and may miss people, detect targets incorrectly, or fail entirely. No accuracy guarantee.
- Some games disable overlays, block capture, or prohibit tools of this type. Blood Strike's anti-cheat rules may penalize unauthorized third-party software.
- Explicit user permission is requested for each capture session. User can stop with the notification.

## Build

- Java 17, Gradle 8.9, Android SDK 35.
- Dependencies: `com.google.mediapipe:tasks-vision:0.10.35`.
- Download the official model file to `app/src/main/assets/efficientdet_lite0.tflite` from Google's model endpoint before running `assembleDebug`. GitHub Actions automates this step.

This prototype compiles on GitHub Actions; live detection quality and overlay compatibility require testing on a physical A55.
