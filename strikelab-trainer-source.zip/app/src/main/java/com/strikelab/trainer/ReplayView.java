package com.strikelab.trainer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Draws playback and AI detections in an isolated app, without controlling another app. */
public final class ReplayView extends View {
    private final Paint p=new Paint(3);
    private Bitmap frame;
    private List<ModelDetector.Target> detections=new ArrayList<>();
    private float lockX=-1,lockY=-1;
    private float manualX=-1,manualY=-1;
    private String message="Load a recording or try the demo screenshot";
    private final RectF dst=new RectF();
    public ReplayView(Context context){super(context);setBackgroundColor(0xFF06111C);}
    public synchronized void show(Bitmap bitmap,List<ModelDetector.Target> targets,String status){
        frame=bitmap;detections=new ArrayList<>(targets);message=status;
        if(!targets.isEmpty()){
            ModelDetector.Target best=null;float bestDist=Float.MAX_VALUE;
            float refX=manualX>=0?manualX:(lockX>=0?lockX:bitmap.getWidth()/2f);
            float refY=manualY>=0?manualY:(lockY>=0?lockY:bitmap.getHeight()/2f);
            for(ModelDetector.Target t:targets){
                float d=(t.headX-refX)*(t.headX-refX)+(t.headY-refY)*(t.headY-refY);
                if(d<bestDist){bestDist=d;best=t;}
            }
            if(best!=null){
                lockX=lockX<0?best.headX:lockX*0.58f+best.headX*0.42f;
                lockY=lockY<0?best.headY:lockY*0.58f+best.headY*0.42f;
            }
        } else {lockX=-1;lockY=-1;}
        postInvalidate();
    }
    public void status(String s){message=s;postInvalidate();}
    @Override protected synchronized void onDraw(Canvas c){
        super.onDraw(c);int w=getWidth(),h=getHeight();c.drawColor(0xFF06111C);
        if(frame==null){p.setColor(0xFFE4EEFF);p.setTextSize(Math.max(18,h/17f));c.drawText(message,30,h/2f,p);return;}
        float scale=Math.min(w/(float)frame.getWidth(),h/(float)frame.getHeight());
        float fw=frame.getWidth()*scale,fh=frame.getHeight()*scale;
        dst.set((w-fw)/2f,(h-fh)/2f,(w+fw)/2f,(h+fh)/2f);
        p.setColor(Color.WHITE);c.drawBitmap(frame,null,dst,p);
        for(ModelDetector.Target t:detections){
            RectF b=t.rect;
            p.setColor(0xFF53F2CE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);
            c.drawRoundRect(new RectF(sx(b.left),sy(b.top),sx(b.right),sy(b.bottom)),6,6,p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF53F2CE);p.setTextSize(Math.max(14,h/23f));
            c.drawText("PERSON "+(int)(t.confidence*100)+"%",sx(b.left),Math.max(20,sy(b.top)-7),p);
            c.drawCircle(sx(t.headX),sy(t.headY),5,p);
        }
        if(lockX>=0){
            float x=sx(lockX),y=sy(lockY);
            p.setStyle(Paint.Style.STROKE);p.setColor(0xFFFFFF79);p.setStrokeWidth(3);
            c.drawCircle(x,y,19,p);c.drawLine(x-29,y,x-12,y,p);c.drawLine(x+12,y,x+29,y,p);
            c.drawLine(x,y-29,x,y-12,p);c.drawLine(x,y+12,x,y+29,p);p.setStyle(Paint.Style.FILL);
        }
        p.setColor(0xCC07111E);c.drawRoundRect(new RectF(12,10,w-12,47),10,10,p);
        p.setColor(0xFFFFFFFF);p.setTextSize(17);c.drawText(message,22,35,p);
        p.setTextSize(13);p.setColor(0xFFE8F9FF);c.drawText("COCO person model · no enemy/team distinction · tap to change preference",16,h-15,p);
    }
    private float sx(float x){return dst.left+x*dst.width()/Math.max(1,frame.getWidth());}
    private float sy(float y){return dst.top+y*dst.height()/Math.max(1,frame.getHeight());}
    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_DOWN && frame!=null){
            float x=event.getX(),y=event.getY();
            manualX=(x-dst.left)/Math.max(.001f,dst.width())*frame.getWidth();
            manualY=(y-dst.top)/Math.max(.001f,dst.height())*frame.getHeight();
            lockX=-1;lockY=-1;invalidate();return true;
        }
        return true;
    }
}
