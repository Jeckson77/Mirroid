package com.strikelab.trainer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import java.io.InputStream;
import java.util.List;

/** Process user-selected images / recorded clips without internet or screen-control permissions. */
public final class ReplayEngine {
    public interface Sink {
        void receive(Bitmap frame,List<ModelDetector.Target> targets,String message);
        void message(String text);
    }
    private final Context context;
    private final Sink sink;
    private final Handler ui=new Handler(android.os.Looper.getMainLooper());
    private final HandlerThread thread=new HandlerThread("StrikeLabReplay");
    private Handler worker;
    private ModelDetector model;
    private MediaMetadataRetriever retriever;
    private volatile boolean playing=false;
    private int generation=0;
    private long timeMs=0,durationMs=0;
    public ReplayEngine(Context context,Sink sink){
        this.context=context.getApplicationContext();this.sink=sink;
        thread.start();worker=new Handler(thread.getLooper());
        worker.post(()->{
            try{model=new ModelDetector(this.context);notice("AI ready • open a replay or try example");}
            catch(Exception e){notice("AI unavailable: "+e.getMessage());}
        });
    }
    private void notice(String msg){ui.post(()->sink.message(msg));}
    private void releaseClip(){if(retriever!=null){try{retriever.release();}catch(Exception ignored){}retriever=null;}}
    private Bitmap fit(Bitmap b){
        if(b==null)return null;
        int max=960;
        if(b.getWidth()<=max)return b;
        float scale=max/(float)b.getWidth();
        Bitmap small=Bitmap.createScaledBitmap(b,max,Math.max(1,(int)(b.getHeight()*scale)),true);
        if(small!=b)b.recycle();return small;
    }
    private void analyze(Bitmap frame,long clock){
        if(frame==null){notice("Could not decode this frame");return;}
        if(model==null){notice("The AI model is unavailable");return;}
        try{
            List<ModelDetector.Target> found=model.find(frame);
            String label="Recorded clip "+(clock/1000f)+"s  •  "+found.size()+" person candidate(s)";
            ui.post(()->sink.receive(frame,found,label));
        } catch(Exception e){notice("Detection failed: "+e.getMessage());}
    }
    public void loadSample(){
        int job=++generation;playing=false;
        worker.post(()->{
            releaseClip();if(job!=generation)return;
            try(InputStream in=context.getAssets().open("example.jpg")){
                Bitmap b=fit(BitmapFactory.decodeStream(in));analyze(b,0);
            }catch(Exception e){notice("Example unavailable: "+e.getMessage());}
        });
    }
    public void open(Uri uri,String type){
        int job=++generation;playing=false;
        worker.post(()->{
            releaseClip();if(job!=generation)return;
            try {
                if(type!=null && type.startsWith("video")){
                    retriever=new MediaMetadataRetriever();retriever.setDataSource(context,uri);
                    String duration=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    durationMs=duration==null?30000L:Math.max(1000,Long.parseLong(duration));
                    timeMs=0;playing=true;renderVideo(job);
                }else{
                    try(InputStream in=context.getContentResolver().openInputStream(uri)){
                        Bitmap b=fit(BitmapFactory.decodeStream(in));
                        analyze(b,0);
                    }
                }
            }catch(Exception e){notice("Could not open file: "+e.getMessage());}
        });
    }
    public void pause(){playing=false;notice("Playback paused");}
    public void resume(){if(retriever!=null){playing=true;int job=generation;worker.post(()->renderVideo(job));}}
    private void renderVideo(int job){
        if(!playing||job!=generation||retriever==null)return;
        try{
            Bitmap bitmap=retriever.getFrameAtTime(timeMs*1000L,MediaMetadataRetriever.OPTION_CLOSEST);
            Bitmap scaled=fit(bitmap);
            if(scaled!=null)analyze(scaled,timeMs);
            timeMs+=360;
            if(timeMs>=durationMs)timeMs=0;
            worker.postDelayed(()->renderVideo(job),70);
        }catch(Exception e){playing=false;notice("Playback stopped: "+e.getMessage());}
    }
    public void close(){playing=false;generation++;worker.post(()->{releaseClip();if(model!=null)model.close();});thread.quitSafely();}
}
