package com.strikelab.trainer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

/** Fully local practice game: simulated enemies and aim assistance only within this app. */
public final class ArenaView extends View {
    private static final class Dummy {
        float x,y,vx,phase;boolean active=true;
    }
    private final Paint p=new Paint(3);
    private final Random random=new Random(9282);
    private final Dummy[] dummies=new Dummy[5];
    private Bitmap scene;
    private float aimX=.5f,aimY=.5f;
    private int hits=0,shots=0,streak=0;
    private boolean firing=false, lockEnabled=true;
    private int firingPointer=-1,aimPointer=-1;
    private long lastNanos=0,lastShotMs=0;
    public ArenaView(Context context,Bitmap bg){
        super(context);scene=bg;setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        for(int i=0;i<dummies.length;i++){
            dummies[i]=new Dummy();dummies[i].x=.16f+i*.14f;
            dummies[i].y=.45f+(i%2)*.13f;dummies[i].vx=(i%2==0?1:-1)*(.028f+i*.004f);
            dummies[i].phase=i*1.4f;
        }
    }
    public void reset(){hits=0;shots=0;streak=0;aimX=.5f;aimY=.5f;lastNanos=0;invalidate();}
    public void toggleLock(){lockEnabled=!lockEnabled;invalidate();}
    public boolean isLockEnabled(){return lockEnabled;}
    public String score(){return "Hits "+hits+" / Shots "+shots+" · Accuracy "+(shots==0?0:100*hits/shots)+"%";}
    private float headY(Dummy d,long now){return d.y + .016f*(float)Math.sin(now*.0018+d.phase);}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);int w=getWidth(),h=getHeight();long now=System.nanoTime();
        float dt=lastNanos==0?0:Math.min(.04f,(now-lastNanos)/1e9f);lastNanos=now;
        p.setColor(Color.WHITE);c.drawColor(0xFF102131);
        if(scene!=null)c.drawBitmap(scene,null,new RectF(0,0,w,h),p);
        p.setColor(0x99001019);c.drawRoundRect(new RectF(12,10,w-12,58),12,12,p);
        p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextSize(19);
        c.drawText("TRAINING ARENA   /   AUTO ACQUIRE: "+(lockEnabled?"ON":"OFF"),25,39,p);
        p.setColor(0xFFC7EAF9);p.setTextSize(16);c.drawText(score(),Math.max(22,w-310),39,p);
        float t=System.currentTimeMillis()*.001f;
        for(Dummy d:dummies){
            d.x+=d.vx*dt;
            if(d.x<.12f){d.x=.12f;d.vx=Math.abs(d.vx);}
            if(d.x>.83f){d.x=.83f;d.vx=-Math.abs(d.vx);}
        }
        Dummy nearest=null;float best=Float.MAX_VALUE;
        for(Dummy d:dummies){
            float hy=headY(d,System.currentTimeMillis());
            float dist=(d.x-aimX)*(d.x-aimX)+(hy-aimY)*(hy-aimY);
            if(dist<best){best=dist;nearest=d;}
            drawDummy(c,d,w,h,hy);
        }
        if(firing && lockEnabled && nearest!=null){
            float correction=Math.min(1f,dt*7.3f);
            aimX+=correction*(nearest.x-aimX);
            aimY+=correction*(headY(nearest,System.currentTimeMillis())-aimY);
        }
        if(firing && nearest!=null && System.currentTimeMillis()-lastShotMs>=145){
            lastShotMs=System.currentTimeMillis();shots++;
            float dx=(nearest.x-aimX)*w,dy=(headY(nearest,System.currentTimeMillis())-aimY)*h;
            if(dx*dx+dy*dy<Math.pow(Math.max(16,h*.07f),2)){
                hits++;streak++;
                // Respawn hit target at a new lane; simulation only.
                nearest.x=.15f+random.nextFloat()*.66f;
                nearest.y=.38f+random.nextFloat()*.21f;
                nearest.vx=(random.nextBoolean()?1:-1)*(.03f+random.nextFloat()*.045f);
            }else{streak=0;}
        }
        // Target lock indicator follows selected training silhouette, not any external game.
        if(nearest!=null){
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(firing&&lockEnabled?0xFF5CF3C1:0xFFFFD860);
            float x=nearest.x*w,hy=headY(nearest,System.currentTimeMillis())*h;
            c.drawRoundRect(new RectF(x-23,hy-22,x+23,hy+65),8,8,p);p.setStyle(Paint.Style.FILL);
        }
        float cx=aimX*w,cy=aimY*h;
        p.setColor(firing?0xFF64FFDE:Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);
        c.drawCircle(cx,cy,14,p);
        c.drawLine(cx-28,cy,cx-8,cy,p);c.drawLine(cx+8,cy,cx+28,cy,p);
        c.drawLine(cx,cy-28,cx,cy-8,p);c.drawLine(cx,cy+8,cx,cy+28,p);
        p.setStyle(Paint.Style.FILL);
        float fireX=w-105,fireY=h-108;
        p.setColor(firing?0xE0F6525A:0xBAFF555B);c.drawCircle(fireX,fireY,67,p);
        p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(18);c.drawText("FIRE",fireX,fireY+6,p);p.setTextAlign(Paint.Align.LEFT);
        p.setColor(0xDD031525);c.drawRoundRect(new RectF(16,h-44,w*.60f,h-7),10,10,p);
        p.setTextSize(15);p.setColor(Color.WHITE);c.drawText("Drag to aim · Hold FIRE to auto-track · This is a standalone simulator",27,h-19,p);
        postInvalidateOnAnimation();
    }
    private void drawDummy(Canvas c,Dummy d,int w,int h,float hy){
        float x=d.x*w,y=hy*h,scale=Math.max(8,h*.028f);
        p.setStyle(Paint.Style.FILL);p.setColor(0xFF102A38);
        c.drawCircle(x,y,scale*.78f,p);
        p.setColor(0xFFE4F2FA);c.drawCircle(x,y,scale*.65f,p);
        p.setColor(0xFF101925);c.drawRect(x-scale,y+scale*.72f,x+scale,y+scale*3.0f,p);
        p.setColor(0xFFE5F1FB);c.drawRoundRect(new RectF(x-scale*.62f,y+scale*.79f,x+scale*.62f,y+scale*2.7f),5,5,p);
        p.setStrokeWidth(scale*.38f);p.setColor(0xFF142638);
        c.drawLine(x-scale*.55f,y+scale*2.5f,x-scale*.8f,y+scale*4.4f,p);
        c.drawLine(x+scale*.55f,y+scale*2.5f,x+scale*.8f,y+scale*4.4f,p);
        p.setStrokeWidth(scale*.31f);
        c.drawLine(x-scale*.6f,y+scale*1.2f,x-scale*1.2f,y+scale*2.3f,p);
        c.drawLine(x+scale*.6f,y+scale*1.2f,x+scale*1.2f,y+scale*2.3f,p);
        p.setColor(0xFF6EFFC9);c.drawCircle(x,y,2.5f,p);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        int a=e.getActionMasked(),index=e.getActionIndex(),id=e.getPointerId(index);
        float w=getWidth(),h=getHeight(),fireX=w-105,fireY=h-108;
        if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_POINTER_DOWN){
            float x=e.getX(index),y=e.getY(index);
            if((x-fireX)*(x-fireX)+(y-fireY)*(y-fireY)<110*110 && firingPointer<0){
                firingPointer=id;firing=true;return true;
            }
            if(aimPointer<0){aimPointer=id;aimX=Math.max(.02f,Math.min(.98f,x/w));aimY=Math.max(.03f,Math.min(.98f,y/h));}
        }else if(a==MotionEvent.ACTION_MOVE){
            if(aimPointer>=0){int pos=e.findPointerIndex(aimPointer);if(pos>=0){
                aimX=Math.max(.02f,Math.min(.98f,e.getX(pos)/w));aimY=Math.max(.03f,Math.min(.98f,e.getY(pos)/h));
            }}
        }else if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_POINTER_UP||a==MotionEvent.ACTION_CANCEL){
            if(id==firingPointer||a==MotionEvent.ACTION_CANCEL){firing=false;firingPointer=-1;}
            if(id==aimPointer||a==MotionEvent.ACTION_CANCEL)aimPointer=-1;
        }
        invalidate();return true;
    }
}
