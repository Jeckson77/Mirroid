package com.strikelab.trainer;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.InputStream;
import java.util.List;

/** Standalone, offline replay detector and local aim-lock practice simulator. */
public final class MainActivity extends Activity {
    private static final int PICK_FILE=918;
    private FrameLayout content;
    private ArenaView arena;
    private ReplayView replay;
    private ReplayEngine replayEngine;
    private TextView status;
    private boolean replayMode=false;
    private Button modeButton,auxButton,openButton;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        getWindow().setStatusBarColor(0xFF06111C);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFF091321);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setOrientation(LinearLayout.HORIZONTAL);toolbar.setGravity(Gravity.CENTER_VERTICAL);toolbar.setPadding(14,7,14,7);
        toolbar.setBackgroundColor(0xFF0E2335);
        TextView brand=new TextView(this);brand.setText("STRIKELAB   A55");brand.setTextSize(17);brand.setTextColor(0xFF66FFE3);brand.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        toolbar.addView(brand,new LinearLayout.LayoutParams(0,55,1));
        modeButton=button(toolbar,"REPLAY MODE",()->setMode(!replayMode));
        auxButton=button(toolbar,"AUTO LOCK: ON",()->{
            if(!replayMode){arena.toggleLock();auxButton.setText("AUTO LOCK: "+(arena.isLockEnabled()?"ON":"OFF"));}
            else {replayEngine.pause();status.setText("Playback paused");}
        });
        openButton=button(toolbar,"OPEN CLIP",this::pickFile);
        button(toolbar,"RESET / DEMO",()->{
            if(replayMode){replayEngine.loadSample();}
            else{arena.reset();status.setText("Arena reset · hold FIRE to practise automatic target acquisition");}
        });
        root.addView(toolbar,new LinearLayout.LayoutParams(-1,65));
        content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        status=new TextView(this);status.setTextSize(13);status.setTextColor(0xFFDAEAF9);status.setPadding(16,7,14,8);status.setBackgroundColor(0xFF0E2335);
        root.addView(status,new LinearLayout.LayoutParams(-1,38));
        setContentView(root);
        Bitmap bg=null;
        try(InputStream in=getAssets().open("arena.jpg")){bg=BitmapFactory.decodeStream(in);}catch(Exception ignored){}
        arena=new ArenaView(this,bg);
        replay=new ReplayView(this);
        replayEngine=new ReplayEngine(this,new ReplayEngine.Sink(){
            @Override public void receive(Bitmap b,List<ModelDetector.Target> targets,String message){replay.show(b,targets,message);status.setText(message+" • model may miss game characters");}
            @Override public void message(String text){status.setText(text);replay.status(text);}
        });
        setMode(false);
    }
    private Button button(LinearLayout parent,String label,Runnable action){
        Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF24506A));
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-2,48);params.setMargins(4,1,4,1);
        parent.addView(b,params);b.setOnClickListener(v->action.run());return b;
    }
    private void setMode(boolean useReplay){
        replayMode=useReplay;content.removeAllViews();content.addView(replayMode?replay:arena,new FrameLayout.LayoutParams(-1,-1));
        modeButton.setText(replayMode?"TRAINING ARENA":"REPLAY MODE");
        auxButton.setText(replayMode?"PAUSE CLIP":"AUTO LOCK: "+(arena.isLockEnabled()?"ON":"OFF"));
        openButton.setVisibility(replayMode?View.VISIBLE:View.GONE);
        if(replayMode){status.setText("Replay analysis • general-person AI, not an enemy classifier");replayEngine.loadSample();}
        else{replayEngine.pause();status.setText("Arena: drag to aim, hold FIRE to track moving targets automatically");}
    }
    private void pickFile(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"video/mp4","video/*","image/jpeg","image/png","image/*"});
        startActivityForResult(intent,PICK_FILE);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK_FILE&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            String type=getContentResolver().getType(data.getData());
            replayEngine.open(data.getData(),type);
        }
    }
    @Override public void onConfigurationChanged(Configuration cfg){super.onConfigurationChanged(cfg);}
    @Override protected void onDestroy(){if(replayEngine!=null)replayEngine.close();super.onDestroy();}
}
