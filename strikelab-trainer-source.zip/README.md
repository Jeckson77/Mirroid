# StrikeLab A55 — Standalone Aim Trainer and Replay Analyzer

Native Android application, designed for Samsung Galaxy A55. **This is NOT a live-match Blood Strike aimbot.**

## Included
- **Arena**: Five moving humanoid target silhouettes, manual swipe aiming, and a press-and-hold FIRE button. The local practice reticle automatically acquires the nearest target while FIRE is held (toggleable). Tracks hits, shots, accuracy. All simulated inside the app.
- **Replay**: Open a video or image through Android's system picker, or use the included screenshot. Uses MediaPipe Tasks + EfficientDet-Lite0 (COCO pretrained) to detect `person` candidates and draw boxes, estimated head guidance, and a smoothed reticle. Runs on the device with no upload to a server. Tap to select a target preference. Audio is not decoded; playback is frame-by-frame analysis, not a real-time media player.
- **No overlay, Accessibility service, touch injection, screen capture, or game modifications**.

## Model limitation
The model is trained on general real-world `person` images, not Blood Strike characters. It does not identify enemies vs teammates. In-game skins, far-away targets, and HUD elements can cause misses and false positives. Head guidance is an estimated position within a bounding box, not a dedicated head detector. A game-specific model requires labeled data and measured evaluation before making accuracy claims. Model uses Google MediaPipe pretrained COCO asset and is downloaded from official Google-hosted storage during CI build.

## Build
The repo ZIP is unpacked by GitHub Actions into `StrikeLabTrainer/`, then the model is fetched into `StrikeLabTrainer/app/src/main/assets/` before running Gradle `assembleDebug` (Java 17, SDK 35, Gradle 8.9). The resulting APK is available as a GitHub Actions artifact. The signed debug APK can be installed on the phone but is not Play Store release-signed.

## Privacy
Only accesses user-selected images/videos through the Android document picker. On-device inference. No tracking or telemetry, network permissions, root permissions, or MediaProjection service.

## Testing
`assembleDebug` validates compilation. On-device runtime performance and actual detection precision must still be validated on the Galaxy A55.
